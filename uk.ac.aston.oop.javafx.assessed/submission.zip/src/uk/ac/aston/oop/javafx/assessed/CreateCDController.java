package uk.ac.aston.oop.javafx.assessed;

import javafx.fxml.FXML;

public class CreateCDController {
	@FXML private boolean gotIt;
	@FXML private String title;
	@FXML private String artist;
	@FXML private int playingTime;
	@FXML private int numberOfTracks;
	
	@FXML public void cancelPressed() {}
	
	@FXML public void addPressed() {}
}
