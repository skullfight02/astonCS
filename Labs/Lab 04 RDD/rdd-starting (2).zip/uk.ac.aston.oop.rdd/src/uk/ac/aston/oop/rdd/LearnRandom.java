package uk.ac.aston.oop.rdd;

import java.util.Random;

public class LearnRandom {

	public static void useRandom(Random rnd) {
		// TODO - write your code here
	}

	public static void main(String[] args) {
		Random rnd = new Random();

		// Don't change the line below!
		LearnRandom.useRandom(rnd);
	}
}
