package uk.ac.aston.oop.rdd.sim;

import java.util.Random;

public class Fox extends Animal {

	@Override
	public int getLifespan() {
		return 30;
	}

	@Override
	public int getMaxLitterSize() {
		return 3;
	}

	@Override
	public double getBreedingProbability() {
		return 0.02;
	}

	@Override
	protected Animal createChild() {
		return new Fox();
	}

	@Override
	public void act(Random rnd) {
		super.act(rnd);
		hunt(rnd);
	}

	protected void hunt(Random rnd) {
		if (isAlive()) {
			// Tries to hunt
			Rabbit rabbit = findAdjacentRabbit();
			if (rabbit != null) {
				moveTo(rabbit.getCell());
				rabbit.setAlive(false);
			} else {
				moveToRandomFreeAdjacentCell(rnd);
			}
		}
	}

	private Rabbit findAdjacentRabbit() {
		for (GridCell adj : getCell().getAdjacent()) {
			for (Animal a : adj.getContents()) {
				if (a instanceof Rabbit) {
					return (Rabbit) a;
				}
			}
		}
		return null;
	}
	
}
