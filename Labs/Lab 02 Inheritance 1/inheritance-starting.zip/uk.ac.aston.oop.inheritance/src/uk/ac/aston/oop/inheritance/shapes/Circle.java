package uk.ac.aston.oop.inheritance.shapes;

import uk.ac.aston.oop.inheritance.util.GraphicsContextWrapper;

public class Circle {

	private double centerX, centerY;
	private double radius;

	public Circle(double centerX, double centerY, double radius) {
		this.centerX = centerX;
		this.centerY = centerY;
		this.radius = radius;
	}

	public double getX() { return centerX; }
	public double getY() { return centerY; }
	public double getWidth()  { return radius * 2; }
	public double getHeight() { return radius * 2; }

	public void draw(GraphicsContextWrapper gc) {
		gc.oval(centerX - radius, centerY - radius, radius * 2, radius * 2);
	}

	public double getRadius() { return radius; }
	
}
