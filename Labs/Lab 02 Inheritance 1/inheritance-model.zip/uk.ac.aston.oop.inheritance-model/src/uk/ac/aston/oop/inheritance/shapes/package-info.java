/**
 * Shapes to be shown in the inheritance program.
 *
 * @author Antonio García-Domínguez
 * @version 1.0
 */
package uk.ac.aston.oop.inheritance.shapes;
