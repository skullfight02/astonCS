/**
 * Main package of the inheritance lab program.
 *
 * @author Antonio García-Domínguez
 * @version 1.0
 */

package uk.ac.aston.oop.inheritance;
